package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class DocumentoFormaPago implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Documento documento;

	private FormaPago formaPago;
	
	private short numero;
	
	/**
	 * Importe en una moneda que puede ser diferente a la del documento, {@link #moneda}
	 */
	private BigDecimal importe;

	/**
	 * Moneda en que esta expresado el importe
	 */
	private Moneda moneda;
	
	/**
	 * Importe en la moneda del documento
	 */
	private BigDecimal total;

	
	public DocumentoFormaPago() {
	}

	public DocumentoFormaPago(Documento documento) {
		this.documento = documento;
		formaPago = FormaPago.EFECTIVO;
		numero = 1;
		importe = documento.getTotal();
		moneda = documento.getMoneda();
		total = importe;
	}

	public Documento getDocumento() {
		return documento;
	}

	public void setDocumento(Documento documento) {
		this.documento = documento;
	}

	public FormaPago getFormaPago() {
		return formaPago;
	}

	public void setFormaPago(FormaPago formaPago) {
		this.formaPago = formaPago;
	}

	public short getNumero() {
		return numero;
	}

	public void setNumero(short numero) {
		this.numero = numero;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public Moneda getMoneda() {
		return moneda;
	}

	public void setMoneda(Moneda moneda) {
		this.moneda = moneda;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((documento == null) ? 0 : documento.hashCode());
		result = prime * result
				+ ((formaPago == null) ? 0 : formaPago.hashCode());
		result = prime * result + numero;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof DocumentoFormaPago))
			return false;
		DocumentoFormaPago other = (DocumentoFormaPago) obj;
		if (documento == null) {
			if (other.documento != null)
				return false;
		} else if (!documento.equals(other.documento))
			return false;
		if (formaPago == null) {
			if (other.formaPago != null)
				return false;
		} else if (!formaPago.equals(other.formaPago))
			return false;
		if (numero != other.numero)
			return false;
		return true;
	}
	
}
