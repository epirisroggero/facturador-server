package uy.com.tmwc.facturator.entity;

import java.math.BigDecimal;

public class Moneda extends CodigoNombreEntity {

	private static final long serialVersionUID = 1L;
	
	/**
	 * Cantidad de decimales
	 */
	private short redondeo;
	
	public BigDecimal redondear(BigDecimal monto) {
		return monto.setScale(redondeo, BigDecimal.ROUND_HALF_UP);
	}

	public short getRedondeo() {
		return redondeo;
	}

	public void setRedondeo(short redondeo) {
		this.redondeo = redondeo;
	}
	
}
