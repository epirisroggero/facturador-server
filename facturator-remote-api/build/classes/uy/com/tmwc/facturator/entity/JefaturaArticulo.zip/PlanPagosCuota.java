package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class PlanPagosCuota implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private PlanPagos planPagos;
	
	private short numero;
	
	private short dias;

	private short mes;

	private BigDecimal porcentaje;

	public PlanPagosCuota(PlanPagos planPagos, short numero, short dias,
			short mes, BigDecimal porcentaje) {
		super();
		this.planPagos = planPagos;
		this.numero = numero;
		this.dias = dias;
		this.mes = mes;
		this.porcentaje = porcentaje;
	}

	public PlanPagosCuota() {
		super();
	}

	public PlanPagos getPlanPagos() {
		return planPagos;
	}

	public void setPlanPagos(PlanPagos planPagos) {
		this.planPagos = planPagos;
	}

	public short getNumero() {
		return numero;
	}

	public void setNumero(short numero) {
		this.numero = numero;
	}

	public short getDias() {
		return dias;
	}

	public void setDias(short dias) {
		this.dias = dias;
	}

	public short getMes() {
		return mes;
	}

	public void setMes(short mes) {
		this.mes = mes;
	}

	public BigDecimal getPorcentaje() {
		return porcentaje;
	}

	public void setPorcentaje(BigDecimal porcentaje) {
		this.porcentaje = porcentaje;
	}

}
