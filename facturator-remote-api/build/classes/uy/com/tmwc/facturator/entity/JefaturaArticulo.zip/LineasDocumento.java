package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LineasDocumento implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<LineaDocumento> lineas = new ArrayList<LineaDocumento>();
	
	private Documento documento;
	
	public LineasDocumento() {}
	
	public LineasDocumento(Documento documento) {
		this.documento = documento;
		
	}
	
	public void add(LineaDocumento linea) {
		linea.setNumeroLinea(lineas.size() + 1);
		lineas.add(linea);
		linea.setDocumento(documento);
	}
	
	public void remove(int numero) {
		lineas.remove(numero - 1);
		int numeroLinea = 1;
		for (LineaDocumento linea : lineas) {
			linea.setNumeroLinea(numeroLinea);
			numeroLinea++;
		}
	}
	
	public List<LineaDocumento> getLineas() {
		return lineas;
	}

	public void setLineas(List<LineaDocumento> lineas) {
		this.lineas = lineas;
	}

	public Documento getDocumento() {
		return documento;
	}
	
	
}
