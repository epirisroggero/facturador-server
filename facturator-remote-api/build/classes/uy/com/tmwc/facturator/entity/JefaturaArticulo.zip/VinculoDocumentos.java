package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import uy.com.tmwc.facturator.utils.Maths;

public class VinculoDocumentos implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Documento factura;
	
	private Recibo recibo;
	
	/**
	 * Es el monto cancelado
	 */
	private BigDecimal monto; 
	
	public BigDecimal getMontoDescuentoEsperado() {
		return factura.calcularMontoDescuentoEsperado(monto);
	}

	public BigDecimal getMontoDescuentoReal() {
		return Maths.calcularMontoDescuento(monto, recibo.getPorcentajeDescuento());
	}

	public BigDecimal getRentaFinanciera() {
		return getMontoDescuentoEsperado().subtract(getMontoDescuentoReal());
	}
	
	public BigDecimal getPorcentajeCancelacion() {
		return Maths.calcularPorcentaje(factura.getTotal(), monto);
	}
	
	/**
	 * Resultado de calcular el porcentaje de cancelacion sobre el total de factura
	 * y luego aplicar ese porcentaje a la renta de la factura
	 * @return
	 */
	public BigDecimal getCuotaparteRentaComercial() {
		return Maths.calcularMontoDescuento(factura.getRentaNetaComercial(), getPorcentajeCancelacion());
	}

	public Documento getFactura() {
		return factura;
	}

	public void setFactura(Documento factura) {
		this.factura = factura;
	}

	public Recibo getRecibo() {
		return recibo;
	}

	public void setRecibo(Recibo recibo) {
		this.recibo = recibo;
	}

	public BigDecimal getMonto() {
		return monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

}
