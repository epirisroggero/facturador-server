package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;

public abstract class Jefatura implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Vendedor jefe;
	
	private BigDecimal comisionPorDefecto;
	
	//public Collection<ParticipacionVendedor> filtrar() //XXX salado!!!!

	public Vendedor getJefe() {
		return jefe;
	}

	public void setJefe(Vendedor jefe) {
		this.jefe = jefe;
	}

	public BigDecimal getComisionPorDefecto() {
		return comisionPorDefecto;
	}

	public void setComisionPorDefecto(BigDecimal comisionPorDefecto) {
		this.comisionPorDefecto = comisionPorDefecto;
	}

}
