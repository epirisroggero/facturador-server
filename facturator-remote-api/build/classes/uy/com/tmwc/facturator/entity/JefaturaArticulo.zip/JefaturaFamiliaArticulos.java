package uy.com.tmwc.facturator.entity;


public class JefaturaFamiliaArticulos extends Jefatura {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private FamiliaArticulos familia;

	public FamiliaArticulos getFamilia() {
		return familia;
	}

	public void setFamilia(FamiliaArticulos familia) {
		this.familia = familia;
	}

}
