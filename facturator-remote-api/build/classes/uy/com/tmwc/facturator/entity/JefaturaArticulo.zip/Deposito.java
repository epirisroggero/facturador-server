package uy.com.tmwc.facturator.entity;

import uy.com.tmwc.facturator.entity.CodigoNombreEntity;

public class Deposito extends CodigoNombreEntity {

}
