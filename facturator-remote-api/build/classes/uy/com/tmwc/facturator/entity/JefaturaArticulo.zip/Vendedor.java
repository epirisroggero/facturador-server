package uy.com.tmwc.facturator.entity;

import java.io.Serializable;

public class Vendedor extends CodigoNombreEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Vendedor() {
		super();
	}

	public Vendedor(String codigo, String nombre) {
		super(codigo, nombre);
	}
	
}
