package uy.com.tmwc.facturator.entity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import uy.com.tmwc.facturator.utils.Maths;

public class Comprobante extends CodigoNombreEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final int VENTA_CREDITO = 1;
	
	public static final int NOTA_CREDITO = 2;
	
	public static final int VENTA_CONTADO = 3;

	public static final int DEVOLUCION_CONTADO = 4;
	
	public static final int RECIBO_COBRO = 5;
	
	/**
	 * Tambien los llamo comprobantes venta (y si, tambien incluyen devoluciones)
	 */
	private static final int[] comprobantesSoportados = {VENTA_CREDITO, NOTA_CREDITO, VENTA_CONTADO, DEVOLUCION_CONTADO};

	private Deposito depositoOrigen;
	
	private Deposito depositoDestino;

	private int tipo;
	
	/**
	 * En orden ascendiente de retraso
	 */
	private List<DescuentoPrometidoComprobante> descuentosPrometidos;

	
	/**
	 * Retorna true si es un comprobante que genera deuda para el cliente.
	 * @return
	 */
	public boolean isCredito() {
		return tipo == 1;
	}
	
	/**
	 * Los documentos de comprobantes que mueven caja deben especificar una {@link FormaPago} 
	 * 
	 * @return
	 */
	public boolean isMueveCaja() {
		return tipo == VENTA_CONTADO || tipo == DEVOLUCION_CONTADO;
	}
	
	/**
	 * {@link #isDevolucion()}
	 * @return
	 */
	public boolean isVenta() {
		return tipo == VENTA_CONTADO || tipo == VENTA_CREDITO;
	}
	
	/**
	 * {@link #isVenta()}
	 * @return
	 */
	public boolean isDevolucion() {
		return tipo == DEVOLUCION_CONTADO || tipo == NOTA_CREDITO;
	}
	
	/**
	 * Usualmente en comprobantes de credito, se trata de un descuento prometido
	 * al cliente (en caso de que cumpla con los pagos en las fechas previstas)
	 * 
	 * Comparada a una venta contado, los precios se incrementan en el
	 * porcentaje dado por este campo. Asimismo, se le promete el mismo
	 * porcentaje como descuento (condicionado al buen pago, como dice mas
	 * arriba)
	 * 
	 * Dado un comprobante, pueden haber varios descuentos prometidos, cada uno
	 * asociado a un lapso de tiempo. Usualmente a mayor lapso (lease atraso)
	 * menor descuento.
	 */
	public BigDecimal getDescuentoPrometido() {
		if (descuentosPrometidos == null) {
			return BigDecimal.ZERO;
		} 
		
		BigDecimal maxDto = BigDecimal.ZERO;
		for (DescuentoPrometidoComprobante d : descuentosPrometidos) {
			if (d.getDescuento().compareTo(maxDto)>0) {
				maxDto = d.getDescuento();
			}
		}
		
		return maxDto;
	}
	
	public BigDecimal calcularMontoDescuentoPrometido(BigDecimal monto) {
		return monto.multiply(getDescuentoPrometido()).divide(
							  Maths.ONE_HUNDRED, 2, RoundingMode.HALF_UP
				);
		
	}

	/**
	 * Retorna el primer descuento prometido cuyo retraso sea >= al retraso proporcionado
	 * (o sea, el mejor descuento posible dado el retraso)
	 * 
	 * @param diasRetraso
	 * @return
	 */
	public BigDecimal getDescuentoPrometido(int diasRetraso) {
		for (DescuentoPrometidoComprobante descuentoPrometido : descuentosPrometidos) { 
			if (diasRetraso <= descuentoPrometido.getRetraso()) {
				return descuentoPrometido.getDescuento();
			}
		}
		return BigDecimal.ZERO; //si me voy de todo rango, no descuento nada. 
	}
	
	public BigDecimal aplicarDescuentoPrometido(BigDecimal importe) {
		return aplicarDescuentoPrometido(importe, 0);
	}
	
	public BigDecimal aplicarDescuentoPrometido(BigDecimal importe, int diasRetraso) {
		BigDecimal descuentoPrometido = getDescuentoPrometido(diasRetraso);
		if (descuentoPrometido.compareTo(BigDecimal.ZERO) == 0) {
			return importe;
		} else {
			return importe.multiply( (Maths.ONE_HUNDRED.subtract(descuentoPrometido)) ).divide(Maths.ONE_HUNDRED);
		}
	}

	public Deposito getDepositoOrigen() {
		return depositoOrigen;
	}

	public void setDepositoOrigen(Deposito depositoOrigen) {
		this.depositoOrigen = depositoOrigen;
	}

	public Deposito getDepositoDestino() {
		return depositoDestino;
	}

	public void setDepositoDestino(Deposito depositoDestino) {
		this.depositoDestino = depositoDestino;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public List<DescuentoPrometidoComprobante> getDescuentosPrometidos() {
		return descuentosPrometidos;
	}

	public void setDescuentosPrometidos(
			List<DescuentoPrometidoComprobante> descuentosPrometidos) {
		this.descuentosPrometidos = descuentosPrometidos;
	}

	/**
	 * 
	 * 
	 * Asumimos que todos los comprobantes soportados por el facturador son emitibles. 
	 * Asi que para los 4 tipos, esto va a dar true. 
	 * 
	 * @return
	 */
	public boolean isEmitible() {
		return Arrays.binarySearch(comprobantesSoportados, tipo) >= 0;
	}

}
