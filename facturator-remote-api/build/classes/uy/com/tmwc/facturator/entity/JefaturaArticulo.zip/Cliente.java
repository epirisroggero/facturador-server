package uy.com.tmwc.facturator.entity;

import uy.com.tmwc.facturator.entity.CodigoNombreEntity;

public class Cliente extends CodigoNombreEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private PlanPagos planPagos;
	
	private PreciosVenta preciosVenta;
	
	private Vendedor vendedor;
	
	private String razonSocial;
	
	private String direccion;
	
	private String rut;

	public PlanPagos getPlanPagos() {
		return planPagos;
	}

	public void setPlanPagos(PlanPagos planPagos) {
		this.planPagos = planPagos;
	}

	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public PreciosVenta getPreciosVenta() {
		return preciosVenta;
	}

	public void setPreciosVenta(PreciosVenta preciosVenta) {
		this.preciosVenta = preciosVenta;
	}
	
}
