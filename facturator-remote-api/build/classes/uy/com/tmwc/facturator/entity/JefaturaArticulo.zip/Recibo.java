package uy.com.tmwc.facturator.entity;

import java.math.BigDecimal;
import java.util.Set;

import uy.com.tmwc.facturator.utils.Maths;


public class Recibo extends DocumentoBase {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Olvide documentarlo. Creo que era el documento.total
	 */
	private BigDecimal cancela;
	
	/**
	 * Porcentaje de descuento en recibo.
	 */
	private BigDecimal porcentajeDescuento;
	
	private Set<VinculoDocumentos> facturasVinculadas;
	
	public BigDecimal getCancela() {
		return cancela;
	}
	
	public BigDecimal getPaga() { //XX no me gusta esto aca, deberia salir del vinculo
		return Maths.descontar(cancela, porcentajeDescuento);
	}

	public BigDecimal getPorcentajeDescuento() {
		return porcentajeDescuento;
	}

	public void setPorcentajeDescuento(BigDecimal porcentajeDescuento) {
		this.porcentajeDescuento = porcentajeDescuento;
	}

	public void setCancela(BigDecimal cancela) {
		this.cancela = cancela;
	}

	public Set<VinculoDocumentos> getFacturasVinculadas() {
		return facturasVinculadas;
	}

	public void setFacturasVinculadas(Set<VinculoDocumentos> facturasVinculadas) {
		this.facturasVinculadas = facturasVinculadas;
	}
	
	
}
