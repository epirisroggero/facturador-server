package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class ResumenEntrega implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Entrega entrega;
	
	private long cantidad;

	public ResumenEntrega() {
	}
	
	public ResumenEntrega(Entrega entrega, long cantidad) {
		super();
		this.entrega = entrega;
		this.cantidad = cantidad;
	}

	/**
	 * 
	 * 
	 * @return
	 */
	public BigDecimal getPeso() {
		return entrega.getRelevancia().multiply(new BigDecimal(cantidad));
	}

	public Entrega getEntrega() {
		return entrega;
	}

	public void setEntrega(Entrega entrega) {
		this.entrega = entrega;
	}

	public long getCantidad() {
		return cantidad;
	}

	public void setCantidad(long cantidad) {
		this.cantidad = cantidad;
	}

}
