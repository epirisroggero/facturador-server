package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class ResumenDocumento implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * En los contextos apropiados, este valor es equivalente a {@link Documento#getTotal()}
	 */
	private BigDecimal total;
	
	/**
	 * equivalente a {@link Documento#getSubTotal()}
	 */
	private BigDecimal subTotal;
	
	/**
	 * equivalente a {@link Documento#getCosto()}
	 */
	private BigDecimal costo;

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}

	public BigDecimal getCosto() {
		return costo;
	}

	public void setCosto(BigDecimal costo) {
		this.costo = costo;
	}

	
}
