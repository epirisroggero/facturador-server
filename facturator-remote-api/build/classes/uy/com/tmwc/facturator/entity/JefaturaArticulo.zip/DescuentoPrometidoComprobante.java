package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class DescuentoPrometidoComprobante implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Comprobante comprobante;
	
	private int retraso;
	
	private BigDecimal descuento;

	public Comprobante getComprobante() {
		return comprobante;
	}

	public void setComprobante(Comprobante comprobante) {
		this.comprobante = comprobante;
	}

	public int getRetraso() {
		return retraso;
	}

	public void setRetraso(int retraso) {
		this.retraso = retraso;
	}

	public BigDecimal getDescuento() {
		return descuento;
	}

	public void setDescuento(BigDecimal descuento) {
		this.descuento = descuento;
	}
	
}
