package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


public class ResumenEntregas implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private HashMap<String/*codigo entrega*/, ResumenEntrega> map;
	
	private BigDecimal gasto;
	
	/**
	 * El valor unitario de entrega es el factor que, aplicado a la relevancia de cierta entrega, 
	 * genera un costo operativo tal que la suma de todos los costos operativos del mes es 
	 * igual al gasto operativo de dicho mes.
	 * 
	 */
	private BigDecimal valorUnitarioEntrega;

	private Collection<ResumenEntrega> resumenPorEntrega;
	
	public ResumenEntregas() {
	}
	
	public ResumenEntregas(Collection<ResumenEntrega> resumenEntrega, BigDecimal gasto) {
		this.gasto = gasto;
		this.map = new HashMap<String, ResumenEntrega>();
		BigDecimal sumaCantidadesConPeso = BigDecimal.ZERO;
		for (ResumenEntrega r : resumenEntrega) {
			map.put(r.getEntrega().getCodigo(), r);
			sumaCantidadesConPeso = sumaCantidadesConPeso.add(r.getPeso());
		}
		valorUnitarioEntrega = sumaCantidadesConPeso.compareTo(BigDecimal.ZERO) == 0 ? null : gasto.divide(sumaCantidadesConPeso, 4, BigDecimal.ROUND_HALF_UP);
		this.resumenPorEntrega = resumenEntrega;
	}

	public BigDecimal getValorUnitarioEntrega() {
		return valorUnitarioEntrega;
	}
	
	public BigDecimal getCostoOperativo(String codigoEntrega) {
		ResumenEntrega r = map.get(codigoEntrega);
		if (r == null) {
			return null; //no deberia pasar
		}
		return r.getEntrega().getCostoOperativo(valorUnitarioEntrega);
	}
	
	public long getCantidad(String codigoEntrega) {
		ResumenEntrega r = map.get(codigoEntrega);
		if (r == null) {
			return 0; //no deberia pasar
		}
		return r.getCantidad();
	}

	public BigDecimal getGasto() {
		return gasto;
	}

	public Map<String, BigDecimal> getAsMap() {
		HashMap<String, BigDecimal> costosMap = new HashMap<String, BigDecimal>();
		for (String codigoEntrega : map.keySet()) {
			costosMap.put(codigoEntrega, getCostoOperativo(codigoEntrega));
		}
		return costosMap;
	}

	public Collection<ResumenEntrega> getResumenPorEntrega() {
		return resumenPorEntrega;
	}
	

}
