package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import uy.com.tmwc.facturator.utils.Maths;

public class Documento extends DocumentoBase implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Vendedor vendedor;
	
	private PreciosVenta preciosVenta;
	
	private Deposito depositoOrigen;
	
	private Deposito depositoDestino;
	
	private Entrega entrega;
	
	private Integer cantidadBultos;
	
	private ComisionesDocumento comisiones;
	
	private LineasDocumento lineas;
	
	/**
	 * a.k.a. condicion de venta.
	 */
	private PlanPagos planPagos;
	
	private CuotasDocumento cuotasDocumento;
	
	private Set<DocumentoFormaPago> pagos;
	
	private BigDecimal saldo;
	
	private Set<VinculoDocumentos> recibosVinculados;

	/**
	 * Dato disponible (y valido) solo en algunos contextos. Permite (por ejemplo) obtener el total sin necesidad de acceder a las lineas.
	 */
	//private ResumenDocumento _resumenDocumento;
	
	/**
	 * El costo operativo real se calcula al final del periodo de liquidacion.
	 * Notar que en el momento de facturar, se calcula un costo operativo en base a la forma de entrega y un costo estimado 
	 * asociado a la misma. Dicho valor es una estimacion, y por lo tanto no necesariamente igual al valor de este campo.
	 *  
	 */
	private BigDecimal costoOperativo;

	/**
	 * equivalente a {@link Documento#getTotal()}
	 */
	private BigDecimal _total;
	
	/**
	 * equivalente a {@link Documento#getSubTotal()}
	 */
	private BigDecimal _subTotal;
	
	/**
	 * equivalente a {@link Documento#getCosto()}
	 */
	private BigDecimal _costo;
	
	public Documento() {
		super();
		comisiones = new ComisionesDocumento(this);
		lineas = new LineasDocumento(this);
		cuotasDocumento = new CuotasDocumento(this);
	}
	
	public Documento(Comprobante c) {
		this();
		setComprobante(c);
		
		setDepositoOrigen(c.getDepositoOrigen());
		setDepositoDestino(c.getDepositoDestino());
		//TODO: moneda 0
	}
	
	/**
	 * Inicializa campos del documento a partir del cliente establecido. No tiene efecto si el valor es null.
	 */
	public void tomarCamposDelCliente() {
		if (cliente == null) {
			return;
		}
		planPagos = cliente.getPlanPagos();
		vendedor = cliente.getVendedor();
		preciosVenta = cliente.getPreciosVenta();
		rut = cliente.getRut();
		razonSocial = cliente.getRazonSocial();
		direccion = cliente.getDireccion();
	}
	
	/**
	 * 
	 * con dtos
	 * con iva
	 * con redondeo
	 * 
	 * @return
	 */
	public BigDecimal getTotal() {
		if (_total != null) {
			return _total;
		}
		return getTotalRedondeado();
	}
	
	private BigDecimal getTotalRedondeado() {
		return getRedondeo(getTotalExacto());
	}
	
	private BigDecimal getRedondeo(BigDecimal exacto) {
		if (moneda == null) {
			return null;
		}
		return exacto.setScale(moneda.getRedondeo(), BigDecimal.ROUND_HALF_UP);
	}
	
	public BigDecimal getTotalExacto() {
		List<LineaDocumento> items = lineas.getLineas();
		BigDecimal sum = BigDecimal.ZERO;
		for (LineaDocumento lineaDocumento : items) {
			sum = sum.add(lineaDocumento.getTotal());
		}
		return sum;
	}
	
	/**
	 * Es la sumatoria de linea.subTotal
	 * 
	 * con dtos
	 * 
	 * @return
	 */
	public BigDecimal getSubTotal() {
		if (_subTotal != null) {
			return _subTotal;
		}
		
		List<LineaDocumento> items = lineas.getLineas();
		BigDecimal sum = BigDecimal.ZERO;
		for (LineaDocumento lineaDocumento : items) {
			sum = sum.add(lineaDocumento.getSubTotal());
		}
		return sum;
	}
	
	/**
	 * Es la sumatoria de linea.iva
	 * 
	 * con dtos
	 * 
	 * @return
	 */
	public BigDecimal getIva() {
		List<LineaDocumento> items = lineas.getLineas();
		BigDecimal sum = BigDecimal.ZERO;
		for (LineaDocumento lineaDocumento : items) {
			sum = sum.add(lineaDocumento.getIva());
		}
		return sum;
	}
	
	/**
	 * Es la sumatoria de linea.dtoImp1 + linea.dtoImp2 + linea.dtoImp3
	 * 
	 * @return
	 */
	public BigDecimal getDescuentos() {
		List<LineaDocumento> items = lineas.getLineas();
		BigDecimal sum = BigDecimal.ZERO;
		for (LineaDocumento lineaDocumento : items) {
			sum = sum.add(lineaDocumento.getImporteDescuentoTotal());
		}
		return sum;
	}
	
	/**
	 * El redondeo se resta al importe exacto de la factura (la suma de las
	 * linas) para obtener el importe "real".
	 */
	public BigDecimal getRedondeo() {
		BigDecimal exacto = getTotalExacto();
		BigDecimal redondeado = getTotalRedondeado();
		return exacto.subtract(redondeado);
	}
	
	/**
	 * El calculo se diferencia notablemente del de la utilidad por linea en que considera el costo 
	 * asociado a la forma de entrega. 
	 * 
	 * @param  costoEntrega Costo de la entrega expresada en la moneda del documento 
	 * @return
	 */
	public BigDecimal getUtilidad(BigDecimal costoEntrega) {
		BigDecimal totalcuesta = BigDecimal.ZERO;
		BigDecimal totalventa = BigDecimal.ZERO;
	    
		for (LineaDocumento linea : lineas.getLineas()) {
			totalcuesta = totalcuesta.add(linea.getCostoTotal());
			totalventa = totalventa.add(linea.getNetoTotal());
		}
		
		if (entrega != null) {
			totalcuesta = totalcuesta.add(costoEntrega);
		}
		
		//ya considerado en las lineas:
//	    undtoglob = psuper.DefinicionComprobante.DefaultDtoEsperado
//	    totalventa = totalventa * (1 - undtoglob / 100) 
	    
		if (totalventa.compareTo(BigDecimal.ZERO) != 0) {
			return (totalventa.subtract(totalcuesta)).multiply(Maths.ONE_HUNDRED).divide(totalventa, 2, BigDecimal.ROUND_HALF_UP); 
		} else {
			return null;
		}
	}
	
	/**
	 * Se trata del porcentaje de ganancia, pero considerando solo la renta comercial y nunca el costo operativo asociado. 
	 * @return
	 */
	public BigDecimal getUtilidad() {
		BigDecimal ventaNeta = getVentaNeta();
		if (ventaNeta.compareTo(BigDecimal.ZERO) == 0) {
			return null;
		} else {
			return getRentaNetaComercial().multiply(Maths.ONE_HUNDRED).divide(ventaNeta, 2, BigDecimal.ROUND_HALF_UP);
		}
	}

	/**
	 * Si el comprobante mueve caja, establece la forma pago por defecto, EFECTIVO.
	 */
	public void establecerFormaPago() {
		if (getComprobante().isMueveCaja() && (pagos == null || pagos.size() == 0)) {
			pagos = new HashSet<DocumentoFormaPago>();
			pagos.add(new DocumentoFormaPago(this));
		}
	}
	
	/**
	 * Algunas verificaciones de correctitud del documento.
	 * Se tratan de reglas no volatiles, mas referidas al modelo de dominio
	 * que a reglas de negocio (si es que esta distincion es tal).  
	 * 
	 */
	public void sanityCheck() {
		if (!comprobante.isCredito() && (planPagos != null || !cuotasDocumento.isEmpty())) {
			throw new RuntimeException("El comprobante no acepta cuotificacion");
		}
		
		boolean mueveCaja = comprobante.isMueveCaja();
		boolean tieneFP = pagos != null && pagos.size() > 0;
		if (mueveCaja ^ tieneFP) {
			throw new RuntimeException("(Solo) los comprobantes que mueven caja tienen pagos");
		}
	}
	
	/**
	 * Tira validaciones sobre los datos ingresados, en busqueda de inconsistencias y 
	 * datos ausentes. 
	 * @throws ValidationException 
	 * 
	 * 
	 */
	public void validate() throws ValidationException {
		if (comprobante.isCredito()) {
			cuotasDocumento.validate();
		}
	}

	public boolean isEmitible() {
		return comprobante.isEmitible();
	}
	
	public boolean isEmitido() {
		return serie != null; //puede ser serie o numero
	}
	
	/**
	 * Calcula la deuda considerando los descuentos prometidos que se pueden 
	 * concretar si el cliente pagara en la fecha especificada. 
	 * 
	 * Cada comprobante define una serie de descuentos prometidos, decrecientes a medida 
	 * que aumentan los dias de retraso. De ellos, el algoritmo se queda con el mejor (desde
	 * el punto de vista del cliente)  descuento que puede ser aplicado.   
	 * 
	 * 
	 * @param today
	 * @return
	 */
	public BigDecimal calcularDeuda(Date today) {
		return cuotasDocumento.calcularDeuda(today, getTotal().subtract(getSaldo()));
	}

	public BigDecimal calcularMontoDescuentoEsperado(BigDecimal monto) {
		return comprobante.calcularMontoDescuentoPrometido(monto);
	}
	
	/**
	 * 
	 * @return costo total
	 */
	public BigDecimal getCosto() {
		if (_costo != null) {
			return _costo;
		}
		
		BigDecimal sum = BigDecimal.ZERO;
		for (LineaDocumento linea : lineas.getLineas()) {
			 sum = sum.add(linea.getCosto());
		}
		return sum;
	}
	
	public void invalidarRedundancia() {
		_costo = null;
		_subTotal = null;
		_total = null;
	}
	
	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public PreciosVenta getPreciosVenta() {
		return preciosVenta;
	}

	public void setPreciosVenta(PreciosVenta preciosVenta) {
		this.preciosVenta = preciosVenta;
	}

	public Deposito getDepositoOrigen() {
		return depositoOrigen;
	}

	public void setDepositoOrigen(Deposito depositoOrigen) {
		this.depositoOrigen = depositoOrigen;
	}

	public Deposito getDepositoDestino() {
		return depositoDestino;
	}

	public void setDepositoDestino(Deposito depositoDestino) {
		this.depositoDestino = depositoDestino;
	}

	public Entrega getEntrega() {
		return entrega;
	}

	public void setEntrega(Entrega entrega) {
		this.entrega = entrega;
	}

	public ComisionesDocumento getComisiones() {
		return comisiones;
	}

	public void setComisiones(ComisionesDocumento comisiones) {
		this.comisiones = comisiones;
	}

	public PlanPagos getPlanPagos() {
		return planPagos;
	}

	public void setPlanPagos(PlanPagos planPagos) {
		this.planPagos = planPagos;
	}

	public LineasDocumento getLineas() {
		return lineas;
	}

	public void setLineas(LineasDocumento lineas) {
		this.lineas = lineas;
	}

	public Integer getCantidadBultos() {
		return cantidadBultos;
	}

	public void setCantidadBultos(Integer cantidadBultos) {
		this.cantidadBultos = cantidadBultos;
	}

	public CuotasDocumento getCuotasDocumento() {
		return cuotasDocumento;
	}

	public void setCuotasDocumento(CuotasDocumento cuotasDocumento) {
		this.cuotasDocumento = cuotasDocumento;
	}

	public Set<DocumentoFormaPago> getPagos() {
		return pagos;
	}

	public void setPagos(Set<DocumentoFormaPago> pagos) {
		this.pagos = pagos;
	}

	public BigDecimal getSaldo() {
		return saldo;
	}

	public void setSaldo(BigDecimal saldo) {
		this.saldo = saldo;
	}

	/**
	 * La renta neta comercial es un concepto util a la hora de liquidar
	 * comisiones. Se define como venta neta - costo, donde venta neta es el
	 * total del documento sin iva y descontando el descuento esperado asociado
	 * al comprobante (ademas, el signo es negativo en caso de devoluciones).
	 * 
	 * Suena raro que se aplique el descuento prometido? El hecho es que si el  
	 * descuento realmente aplicado (en la cobranza) es menor, el beneficio
	 * para fulltime aparece como ganancia financiera, que se calcula en otro lado.
	 * 
	 * 
	 * @return
	 */
	public BigDecimal getRentaNetaComercial() {
		BigDecimal ventaNeta = getVentaNeta();
		BigDecimal costo = getCosto();
		BigDecimal costoCSigno = comprobante.isDevolucion() ? costo.negate() : costo;
		return ventaNeta.subtract(costoCSigno);
	}

	/**
	 * Ver definicion de venta neta en {@link #getRentaNetaComercial()}
	 * 
	 * @return
	 */
	public BigDecimal getVentaNeta() {
		BigDecimal subTotal = getSubTotal();
		BigDecimal ventaNeta = comprobante.aplicarDescuentoPrometido(subTotal); //llamemosle neta, mas por historia que otra cosa
		return comprobante.isDevolucion() ? ventaNeta.negate() : ventaNeta;
	}

	public BigDecimal getCostoOperativo() {
		return costoOperativo;
	} 

	public void setCostoOperativo(BigDecimal costoOperativo) {
		this.costoOperativo = costoOperativo;
	}

	public void setTotal(BigDecimal total) {
		_total = total;
	}

	public void setSubTotal(BigDecimal subTotal) {
		_subTotal = subTotal;
	}

	public void setCosto(BigDecimal costo) {
		_costo = costo;
	}

	public Set<VinculoDocumentos> getRecibosVinculados() {
		return recibosVinculados;
	}

	public void setRecibosVinculados(Set<VinculoDocumentos> recibosVinculados) {
		this.recibosVinculados = recibosVinculados;
	}

}
