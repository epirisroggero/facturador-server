package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import uy.com.tmwc.facturator.utils.Dates;

public class CuotaDocumento implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Documento documento;
	
	private int numero;
	
	private Date fecha;
	
	private BigDecimal importe;
	
	public CuotaDocumento() {
		super();
	}

	public CuotaDocumento(Documento documento, int numero, Date fecha,
			BigDecimal importe) {
		super();
		this.documento = documento;
		this.numero = numero;
		this.fecha = fecha;
		this.importe = importe;
	}
	
	public int getRetrasoDias(Date to) {
		return Dates.getDaysBetween(fecha, to);
	}

	public Documento getDocumento() {
		return documento;
	}

	public void setDocumento(Documento documento) {
		this.documento = documento;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	
}
