package uy.com.tmwc.facturator.entity;

public class PreciosVenta extends CodigoNombreEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PreciosVenta() {
		super();
	}

	public PreciosVenta(String codigo, String nombre) {
		super(codigo, nombre);
	}
	
}
