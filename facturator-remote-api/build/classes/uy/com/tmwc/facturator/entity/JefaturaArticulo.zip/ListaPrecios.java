package uy.com.tmwc.facturator.entity;


public class ListaPrecios extends CodigoNombreEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ListaPrecios() {
		super();
	}

	public ListaPrecios(String codigo, String nombre) {
		super(codigo, nombre);
	}
	
}
