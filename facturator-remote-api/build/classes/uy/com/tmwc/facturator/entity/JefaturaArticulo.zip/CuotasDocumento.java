package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import uy.com.tmwc.facturator.utils.Dates;
import uy.com.tmwc.facturator.utils.Maths;

public class CuotasDocumento implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<CuotaDocumento> cuotas;
	
	private Documento documento;
	
	public CuotasDocumento() {
	}
	
	public CuotasDocumento(Documento documento) {
		super();
		this.documento = documento;
		cuotas = new ArrayList<CuotaDocumento>();
	}
	
	public BigDecimal getSumaCuotas() {
		if (cuotas == null) {
			return BigDecimal.ZERO;
		}
		BigDecimal sum = BigDecimal.ZERO;
		for (CuotaDocumento cuota : cuotas) {
			sum  = sum.add(cuota.getImporte());
		}
		return sum;
	}

	public void validate() throws ValidationException {
		if (getSumaCuotas().compareTo(documento.getTotal()) != 0) {
			throw new ValidationException("El total de cuotas (" + getSumaCuotas() + ") es diferente al importe de la factura (" + documento.getTotal() + ")");
		}
	}
	
	/**
	 * 
	 * @param monto Monto a cubrir
	 * @return Cantidad de cuotas que cubre (completamente) el monto especificado
	 */
	public int getCuotasCubiertas(BigDecimal monto) {
		int cuotasCubiertas = 0; 
		BigDecimal sumaCuotas = BigDecimal.ZERO;
	    for (CuotaDocumento cuotaDocumento : cuotas) {
			BigDecimal sumaCuotasTemp = sumaCuotas.add(cuotaDocumento.getImporte());
			if (sumaCuotasTemp.compareTo(monto) > 0) {
				break;
			} 
			sumaCuotas = sumaCuotasTemp;
			cuotasCubiertas ++;
		}
	    return cuotasCubiertas;
	}

	public List<CuotaDocumento> getCuotas() {
		return cuotas;
	}

	public void setCuotas(List<CuotaDocumento> cuotas) {
		this.cuotas = cuotas;
	}

	public void clear() {
		cuotas.clear();
	}

	/**
	 * TODO: no esta todo soportado, ver comentarios en {@link PlanPagos}
	 */
	public void inicializarCuotas() {
		PlanPagos plan = documento.getPlanPagos();
		if (plan == null) {
			cuotas.clear();
			return;
		} 
		
		cuotas.clear();
		
		BigDecimal total = documento.getTotal();
		BigDecimal acumCuotas = BigDecimal.ZERO;
		BigDecimal redondeoMinValue;
		if (plan.isAcumularDecimales()) {
			redondeoMinValue = BigDecimal.ONE.scaleByPowerOfTen(-1*documento.getMoneda().getRedondeo());
		} else {
			redondeoMinValue = new BigDecimal("0.01");
		}
		//XXX pasar a planPagos!
		if (plan.isCuotasIguales()) {
			Date vencimiento = (Date) documento.getFecha().clone();
			Dates.addMonthsToDate(vencimiento, plan.getPrimerMes());
			Dates.addDaysToDate(vencimiento, plan.getPrimerDia());
			BigDecimal importeCuota;
			if (plan.isAcumularDecimales()) {
				importeCuota = total.divide(new BigDecimal(plan.getCantidadCuotas()), documento.getMoneda().getRedondeo(), BigDecimal.ROUND_HALF_UP);
			} else {
				importeCuota = total.divide(new BigDecimal(plan.getCantidadCuotas()), 2, BigDecimal.ROUND_HALF_UP); //no acumular decimales es dejar los importes con el maximo 
				//de decimales posible, o sea 2.
			}
			for (int i=0; i<plan.getCantidadCuotas(); i++) {
				BigDecimal importe = importeCuota;
				
				cuotas.add(new CuotaDocumento(documento, i+1, vencimiento, importe));
				
				acumCuotas = acumCuotas.add(importe);
				vencimiento = (Date) vencimiento.clone();
				Dates.addMonthsToDate(vencimiento, plan.getSeparacionMes());
				Dates.addDaysToDate(vencimiento, plan.getSeparacionDia());
			}
		} else {
			Date vencimiento = (Date) documento.getFecha().clone();
			int numero = 1;
			int decimales = plan.isAcumularDecimales() ? documento.getMoneda().getRedondeo() : 2;
			for (PlanPagosCuota ppc : plan.getPlanPagosCuotas()) {
				Dates.addMonthsToDate(vencimiento, plan.getSeparacionMes());
				Dates.addDaysToDate(vencimiento, plan.getSeparacionDia());
				vencimiento = (Date) vencimiento.clone();
				
				BigDecimal importe = total.multiply(ppc.getPorcentaje()).divide(Maths.ONE_HUNDRED, decimales, BigDecimal.ROUND_HALF_UP);
				cuotas.add(new CuotaDocumento(documento, numero++, vencimiento, importe));
				acumCuotas = acumCuotas.add(importe);
			}
		}

		BigDecimal diferencia = total.subtract(acumCuotas);
		
		Iterator<CuotaDocumento> iterator;
		if (diferencia.signum() > 0) {
			iterator = cuotas.iterator();
		} else {
			final ListIterator<CuotaDocumento> listIterator = cuotas.listIterator(cuotas.size()); //LinkedList.descendingIterator no esta implementado en GWT.
			
			iterator = new Iterator<CuotaDocumento>() {
				public boolean hasNext() {
					return listIterator.hasPrevious();
				}
				public CuotaDocumento next() {
					return listIterator.previous();
				}
				public void remove() {
					throw new UnsupportedOperationException();
				}
			};
		}
		
		BigDecimal valueToAdd = redondeoMinValue.multiply(new BigDecimal(diferencia.signum()));
		while (diferencia.signum() != 0 && iterator.hasNext()) {
			CuotaDocumento cuota = iterator.next();
			cuota.setImporte(cuota.getImporte().add(valueToAdd));
			diferencia = diferencia.subtract(valueToAdd);
		}

	}
	
	public boolean isEmpty() {
		return cuotas.size() == 0;
	}

	public BigDecimal sumarCuotas(int desde, int hasta) {
		BigDecimal suma = BigDecimal.ZERO;
		for (int i=desde; i<=hasta; i++) {
			suma = suma.add(cuotas.get(i).getImporte());
		}
		return suma;
	}
	
	public BigDecimal calcularDeuda(Date today, BigDecimal cancelado) {
		int primerCuotaSinCancelar /*base 0*/ = getCuotasCubiertas(cancelado);
		
		if (primerCuotaSinCancelar > cuotas.size()) {
			return BigDecimal.ZERO;
		}
		
		BigDecimal favorable = cancelado.subtract(sumarCuotas(0, primerCuotaSinCancelar - 1)); //monto sobrante al cancelar cuotas *completas*

		BigDecimal deuda = BigDecimal.ZERO;
		
		for (int i = primerCuotaSinCancelar; i < cuotas.size(); i++) {
			CuotaDocumento cuota = cuotas.get(i);
			BigDecimal importe = cuota.getImporte().subtract(favorable); //solo puede restar algo en la primer iteracion, luego siempre favorable == 0
			int retraso = cuota.getRetrasoDias(today);
			BigDecimal importeConDto = documento.getComprobante().aplicarDescuentoPrometido(importe, retraso);
			deuda = deuda.add(importeConDto);
			
			favorable = BigDecimal.ZERO;
		}
		
		return deuda;
	}
	
	public Documento getDocumento() {
		return documento;
	}

}
