package uy.com.tmwc.facturator.entity;


public class JefaturaArticulo extends Jefatura {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Articulo articulo;

	public Articulo getArticulo() {
		return articulo;
	}

	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}

}
