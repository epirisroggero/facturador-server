package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import uy.com.tmwc.facturator.entity.Vendedor;
import uy.com.tmwc.facturator.utils.Maths;


public class ParticipacionVendedor implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Documento documento;

	private Vendedor vendedor;
	
	private BigDecimal porcentaje = BigDecimal.ZERO;
	
	public ParticipacionVendedor() {
		super();
	}
	
	public BigDecimal getCuotaparteOperativos() {
		BigDecimal costoOperativo = documento.getCostoOperativo();
		return costoOperativo != null ? calcularCuotaparte(costoOperativo) : null;
	}
	
	public BigDecimal getCuotaparteRentaComercial() {
		return calcularCuotaparte(documento.getRentaNetaComercial());
	}
	
	private BigDecimal calcularCuotaparte(BigDecimal monto) {
		return Maths.calcularMontoDescuento(monto, porcentaje);
	}

	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public BigDecimal getPorcentaje() {
		return porcentaje;
	}

	public void setPorcentaje(BigDecimal porcentaje) {
		this.porcentaje = porcentaje;
	}

	public Documento getDocumento() {
		return documento;
	}

	public void setDocumento(Documento documento) {
		this.documento = documento;
	}
	
}
