package uy.com.tmwc.facturator.entity;

import java.math.BigDecimal;

public class Entrega extends CodigoNombreEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	
	/**
	 * Costo expresado en dolares
	 */
	private BigDecimal costo;
	
	private BigDecimal relevancia;
	
	/**
	 * En realidad no estoy seguro si dejarlo aca o en ResumenEntregas
	 * 
	 * @param valorUnitarioEntrega
	 * @return
	 */
	public BigDecimal getCostoOperativo(BigDecimal valorUnitarioEntrega) {
		return relevancia.multiply(valorUnitarioEntrega);
	}

	public String getMonedaCosto() {
		return "2"; //XXX constante!!!
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public BigDecimal getCosto() {
		return costo;
	}

	public void setCosto(BigDecimal costo) {
		this.costo = costo;
	}

	public BigDecimal getRelevancia() {
		return relevancia;
	}

	public void setRelevancia(BigDecimal relevancia) {
		this.relevancia = relevancia;
	}
	
}
