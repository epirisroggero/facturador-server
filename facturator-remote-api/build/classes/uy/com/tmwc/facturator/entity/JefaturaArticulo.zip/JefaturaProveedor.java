package uy.com.tmwc.facturator.entity;


public class JefaturaProveedor extends Jefatura {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Proveedor proveedor;

	public Proveedor getProveedor() {
		return proveedor;
	}

	public void setProveedor(Proveedor proveedor) {
		this.proveedor = proveedor;
	}
	
}
