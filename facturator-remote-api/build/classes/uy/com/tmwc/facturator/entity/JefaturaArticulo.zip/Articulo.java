package uy.com.tmwc.facturator.entity;

import java.math.BigDecimal;
import java.util.Date;

public class Articulo extends CodigoNombreEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Iva iva;
	
	private BigDecimal costo;
	
	private Moneda monedaCosto;
	
	private Date fechaCosto;
	
	private Proveedor proveedor;
	
	private FamiliaArticulos familia;

	public Iva getIva() {
		return iva;
	}

	public void setIva(Iva iva) {
		this.iva = iva;
	}

	public BigDecimal getTasaIva() {
		return iva == null ? BigDecimal.ZERO : iva.getTasa();
	}

	public BigDecimal getCosto() {
		return costo;
	}

	public void setCosto(BigDecimal costo) {
		this.costo = costo;
	}

	public Moneda getMonedaCosto() {
		return monedaCosto;
	}

	public void setMonedaCosto(Moneda monedaCosto) {
		this.monedaCosto = monedaCosto;
	}

	public Date getFechaCosto() {
		return fechaCosto;
	}

	public void setFechaCosto(Date fechaCosto) {
		this.fechaCosto = fechaCosto;
	}

	public Proveedor getProveedor() {
		return proveedor;
	}

	public void setProveedor(Proveedor proveedor) {
		this.proveedor = proveedor;
	}

	public FamiliaArticulos getFamilia() {
		return familia;
	}

	public void setFamilia(FamiliaArticulos familia) {
		this.familia = familia;
	}

}
