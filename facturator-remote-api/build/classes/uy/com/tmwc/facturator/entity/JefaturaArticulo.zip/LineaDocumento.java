package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;

import uy.com.tmwc.facturator.utils.Maths;

public class LineaDocumento implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int numeroLinea;
	
	private int cantidad;
	
	private Articulo articulo;

	/**
	 * El concepto se inicializa con el nombre del articulo, pero puede ser
	 * editado por el usuario
	 */
	private String concepto;
	
	/**
	 * precio unitario del articulo. Siempre se expresa sin impuestos.
	 * 
	 * unitario
	 * sin iva
	 * 
	 */
	private BigDecimal precio = BigDecimal.ZERO;
	
	private BigDecimal costo = BigDecimal.ZERO;
	
	/**
	 * Porcentaje de descuento en la linea
	 */
	private BigDecimal descuento = BigDecimal.ZERO;
	
	private Documento documento;
	
	/**
	 * es el total de la linea
	 * 
	 * con IVA
	 * con dtos
	 * 
	 * @return
	 */
	public BigDecimal getTotal() {
		return getSubTotal().add(getIva());
	}
	
	/**
	 * es el subtotal por linea
	 * 
	 * con dtos
	 * NO iva
	 *  
	 */
	public BigDecimal getSubTotal() {
		return getPrecioUnitario().multiply(new BigDecimal(cantidad));
	}
	
	/**
	 * precio unitario con descuentos aplicados.
	 * 
	 * con dtos.
	 * 
	 * @return
	 */
	public BigDecimal getPrecioUnitario() {
		return precio.subtract(getImporteDescuento());
	}
	
	/**
	 * El importe del descuento.
	 * 
	 * unitario
	 * no iva
	 * 
	 * @return
	 */
	public BigDecimal getImporteDescuento() {
		return precio.multiply(descuento).divide(Maths.ONE_HUNDRED);
	}
	
	/**
	 * {@link #getImporteDescuento()} * {@link #getCantidad()}
	 * 
	 * @return
	 */
	public BigDecimal getImporteDescuentoTotal() {
		return getImporteDescuento().multiply(new BigDecimal(getCantidad()));
	}
	
	/**
	 * El neto es el precio unitario luego de descuentos (incluyendo el descuento prometido del comprobante).
	 * 
	 * @return
	 */
	public BigDecimal getNeto() {
		return getPrecioUnitario().multiply(
				BigDecimal.ONE.subtract(documento.getComprobante().getDescuentoPrometido().divide(Maths.ONE_HUNDRED)));
	}
	
	/**
	 * {@link #neto} *  {@link #cantidad}
	 * 
	 * @return
	 */
	public BigDecimal getNetoTotal() {
		return getNeto().multiply(new BigDecimal(cantidad));
	}
	
	/**
	 * Establecer el valor neto es una forma indirecta de modificar el precio unitario.
	 * Se calcula el precio que de el valor neto especificado, tomando en cuenta descuento(s)
	 * 
	 * @param value
	 */
	public void setNeto(BigDecimal value) {
		BigDecimal documentoPrometido = documento.getComprobante().getDescuentoPrometido();
		BigDecimal quot = ( Maths.ONE_HUNDRED.subtract(descuento) ).multiply( (Maths.ONE_HUNDRED.subtract(documentoPrometido)) );
		
		precio = Maths.ONE_HUNDRED.multiply(Maths.ONE_HUNDRED).multiply(value)
				.divide(quot, 2, RoundingMode.HALF_UP);
	}

	public void elegirArticulo(Articulo articulo) {
		this.articulo = articulo;
		if (articulo != null) {
			concepto = articulo.getNombre();
		}
	}
	
	/**
	 * es el  total de iva por linea
	 * 
	 * con/luego de dtos.
	 * 
	 * @return
	 */
	public BigDecimal getIva() {
		return getSubTotal().multiply(getTasaIva()).divide(Maths.ONE_HUNDRED, 2, RoundingMode.HALF_UP);
	}
	
	public BigDecimal getTasaIva() {
		if (articulo == null) {
			return BigDecimal.ZERO;
		} else {
			return articulo.getTasaIva();
		}
	}
	
	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public Articulo getArticulo() {
		return articulo;
	}

	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}

	public BigDecimal getPrecio() {
		return precio;
	}

	public void setPrecio(BigDecimal precio) {
		this.precio = precio;
	}
	
	public void setPrecioUnitarioSinDescuentoPrometido(BigDecimal precio) {
	    double t = 1 - documento.getComprobante().getDescuentoPrometido().doubleValue() / 100;
	    if (t != 0) {
	        this.precio = new BigDecimal(precio.doubleValue() / t);
	    }
	}

	public BigDecimal getCosto() {
		return costo;
	}
	
	/**
	 * {@link #costo} *  {@link #cantidad}
	 * 
	 * @return
	 */
	public BigDecimal getCostoTotal() {
		return costo == null ? BigDecimal.ZERO : costo.multiply(new BigDecimal(cantidad));
	}

	public void setCosto(BigDecimal costo) {
		this.costo = costo;
	}

	public BigDecimal getDescuento() {
		return descuento;
	}

	public void setDescuento(BigDecimal descuento) {
		this.descuento = descuento;
	}
	
	public BigDecimal getPorcentajeUtilidad() {
		BigDecimal neto = getNeto();
		if (neto.compareTo(BigDecimal.ZERO) == 0) {
			return null;
		}
		BigDecimal utilidad = getUtilidad();
		return utilidad.compareTo(BigDecimal.ZERO) == 0 ? BigDecimal.ZERO : new BigDecimal(utilidad.doubleValue() * 100 / neto.doubleValue());
		
//	    pImporteNetoUnitario = PrecioUnitario * (1 - PorcgDescuento / 100)
//	    For Each undto In colDtos
//	        pImporteNetoUnitario = pImporteNetoUnitario * (1 - undto.Porcentaje / 100)
//	    Next undto
//	    
//	    pImporteNeto = pImporteNetoUnitario * cantidad
//	    If pImporteNeto = 0 Then
//	        pUtilidad = 0
//	        pPorcgUtilidad = 0
//	    Else
//	        pUtilidad = pImporteNeto - CostoTotal
//	        'wARNING: pa zafar
//	        If pImporteNeto = 0 Then
//	            pPorcgUtilidad = 0
//	        Else
//	            pPorcgUtilidad = pUtilidad * 100 / pImporteNeto
//	        End If
//	    End If
		
	}
	
	public BigDecimal getUtilidad() {
		return getNeto().subtract(getCosto());
	}

	public Documento getDocumento() {
		return documento;
	}

	public void setDocumento(Documento documento) {
		this.documento = documento;
	}

	public int getNumeroLinea() {
		return numeroLinea;
	}

	public void setNumeroLinea(int numeroLinea) {
		this.numeroLinea = numeroLinea;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}
	
}
