package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public abstract class DocumentoBase implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected String docId;

	protected String serie;

	protected Long numero;
	
	protected Date fecha;
	
	protected BigDecimal cotizacion = BigDecimal.ZERO;
	
	protected Cliente cliente;
	
	protected Moneda moneda;
	
	protected String razonSocial;
	
	protected String direccion;
	
	protected String rut;

	protected Comprobante comprobante;
	
	protected String notas;

	protected Date registroFecha;
	
	protected Date registroHora;
	
	public DocumentoBase() {
		super();
		cotizacion = BigDecimal.ZERO;
	}
	
	public String getSerie() {
		return serie;
	}

	public void setSerie(String serie) {
		this.serie = serie;
	}

	public Long getNumero() {
		return numero;
	}

	public void setNumero(Long numero) {
		this.numero = numero;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public BigDecimal getCotizacion() {
		return cotizacion;
	}

	public void setCotizacion(BigDecimal cotizacion) {
		this.cotizacion = cotizacion;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Moneda getMoneda() {
		return moneda;
	}

	public void setMoneda(Moneda moneda) {
		this.moneda = moneda;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public Comprobante getComprobante() {
		return comprobante;
	}

	public void setComprobante(Comprobante comprobante) {
		this.comprobante = comprobante;
	}

	public String getNotas() {
		return notas;
	}

	public void setNotas(String notas) {
		this.notas = notas;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public Date getRegistroFecha() {
		return registroFecha;
	}

	public void setRegistroFecha(Date registroFecha) {
		this.registroFecha = registroFecha;
	}

	public Date getRegistroHora() {
		return registroHora;
	}

	public void setRegistroHora(Date registroHora) {
		this.registroHora = registroHora;
	}

}
