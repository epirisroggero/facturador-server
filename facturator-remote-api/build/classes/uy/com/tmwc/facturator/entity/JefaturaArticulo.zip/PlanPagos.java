package uy.com.tmwc.facturator.entity;

import java.util.List;


/**
 * No estoy soportando: recargo, decimales?, el tema de que sea a mes vencido o fecha factura (que no vi que funcionara siquiera en libra)
 * 
 * @author Mauro
 *
 */
public class PlanPagos extends CodigoNombreEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private short cantidadCuotas;

	private boolean cuotasIguales;

	private short primerDia;

	private short primerMes;

	private short separacionDia;

	private short separacionMes;
	
	private boolean acumularDecimales;
	
	List<PlanPagosCuota> planPagosCuotas;
	
	public short getCantidadCuotas() {
		return cantidadCuotas;
	}

	public void setCantidadCuotas(short cantidadCuotas) {
		this.cantidadCuotas = cantidadCuotas;
	}

	public boolean isCuotasIguales() {
		return cuotasIguales;
	}

	public void setCuotasIguales(boolean cuotasIguales) {
		this.cuotasIguales = cuotasIguales;
	}

	public short getPrimerDia() {
		return primerDia;
	}

	public void setPrimerDia(short primerDia) {
		this.primerDia = primerDia;
	}

	public short getPrimerMes() {
		return primerMes;
	}

	public void setPrimerMes(short primerMes) {
		this.primerMes = primerMes;
	}

	public short getSeparacionDia() {
		return separacionDia;
	}

	public void setSeparacionDia(short separacionDia) {
		this.separacionDia = separacionDia;
	}

	public short getSeparacionMes() {
		return separacionMes;
	}

	public void setSeparacionMes(short separacionMes) {
		this.separacionMes = separacionMes;
	}

	public List<PlanPagosCuota> getPlanPagosCuotas() {
		return planPagosCuotas;
	}

	public void setPlanPagosCuotas(List<PlanPagosCuota> planPagosCuotas) {
		this.planPagosCuotas = planPagosCuotas;
	}

	public boolean isAcumularDecimales() {
		return acumularDecimales;
	}

	public void setAcumularDecimales(boolean acumularDecimales) {
		this.acumularDecimales = acumularDecimales;
	}

}
