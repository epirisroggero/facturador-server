package uy.com.tmwc.facturator.entity;

public enum FechaPrimeraCuotaType {

	FechaFactura,
	MesVencido
	
}
