package uy.com.tmwc.facturator.entity;

public class Proveedor extends CodigoNombreEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
