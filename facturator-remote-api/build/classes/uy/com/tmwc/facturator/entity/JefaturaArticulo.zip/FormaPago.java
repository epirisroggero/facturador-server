package uy.com.tmwc.facturator.entity;

public class FormaPago extends CodigoNombreEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final FormaPago EFECTIVO = new FormaPago("1", "Efectivo_INTERNAL_USE"); //uso interno porque no esta leida de la base

	public FormaPago() {
		super();
	}

	public FormaPago(String codigo, String nombre) {
		super(codigo, nombre);
	}

}
