package uy.com.tmwc.facturator.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class ArticuloPrecio implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Articulo articulo;
	
	private Moneda moneda;
	
	/**
	 * Precio 
	 * 
	 * sin tiene o no iva incluido depende del valor de {@link #precioConIva}
	 */
	private BigDecimal precio;
	
	private boolean precioConIva;
	
	/**
	 * Retorna el precio sin impuestos. Notar que {@link #getPrecio()} puede retornar con o sin impuestos.
	 * 
	 * @return
	 */
	public BigDecimal getImporteArticuloSinIVA() {
		if (precioConIva) {
			Iva iva = articulo.getIva();
			if (iva == null) {
				return null; //no lo puedo calcular. Estaria bueno hacer log de esta situacion, porque posiblemente indique un problema de datos y no de este programa.
			}
			return iva.calcularNeto(precio);
		} else {
			return precio;
		}
	}

	public Articulo getArticulo() {
		return articulo;
	}

	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}

	public Moneda getMoneda() {
		return moneda;
	}

	public void setMoneda(Moneda moneda) {
		this.moneda = moneda;
	}

	public BigDecimal getPrecio() {
		return precio;
	}

	public void setPrecio(BigDecimal precio) {
		this.precio = precio;
	}

	public boolean isPrecioConIva() {
		return precioConIva;
	}

	public void setPrecioConIva(boolean precioConIva) {
		this.precioConIva = precioConIva;
	}
	
}
